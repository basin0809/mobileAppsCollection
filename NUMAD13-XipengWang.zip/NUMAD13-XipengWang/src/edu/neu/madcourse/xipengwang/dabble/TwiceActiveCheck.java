package edu.neu.madcourse.xipengwang.dabble;

import java.util.ArrayList;

public class TwiceActiveCheck {
	public static ArrayList<Integer> musicTwicePressed = new ArrayList<Integer>();
}

package edu.neu.madcourse.xipengwang.comm;

public class OppNameMyName {
	public static  String myName="@#$";
	public static  String oppName="@#$";
	public static  String myFakeName = "$%";
	public static  String oppFakeName = "$%";
}

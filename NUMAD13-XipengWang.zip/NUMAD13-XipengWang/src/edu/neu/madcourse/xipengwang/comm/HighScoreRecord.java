package edu.neu.madcourse.xipengwang.comm;

import java.util.ArrayList;

public class HighScoreRecord {
	public static  String[] highscore={"0","0","0","0"};
	
}

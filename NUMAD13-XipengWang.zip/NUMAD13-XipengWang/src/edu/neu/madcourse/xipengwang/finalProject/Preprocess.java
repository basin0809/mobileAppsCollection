package edu.neu.madcourse.xipengwang.finalProject;

import org.opencv.core.Mat;

public interface Preprocess {
	void doPreprocess(Mat original, Mat result);
}

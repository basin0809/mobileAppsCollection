/** Automatically generated file. DO NOT MODIFY */
package edu.neu.madcourse.xipengwang;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}